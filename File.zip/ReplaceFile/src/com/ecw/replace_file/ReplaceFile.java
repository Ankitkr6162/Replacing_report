package com.ecw.replace_file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class ReplaceFile {

	public static void main(String[] args) {
		 
		Path sourceFilePath = Paths.get("C:\\Users\\ankit.kumarsingh\\Desktop\\SamplePdf.pdf");
		Path targetFilePath = Paths.get("C:\\Users\\ankit.kumarsingh\\Desktop\\Replace.pdf");
		
		try {
			Files.copy(sourceFilePath, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
			Files.delete(sourceFilePath);
			System.out.println("File got replaced and older file got deleted");
		} catch (IOException e) {
			System.err.println("An error occured "+e.getMessage());
		}
	}
}
